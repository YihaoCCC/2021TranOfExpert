import Vue from 'vue'
export let road = new Vue()
