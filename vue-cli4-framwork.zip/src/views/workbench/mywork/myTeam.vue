<template>
    <div >
        <el-row :gutter="12" v-for="(item,index) in myteam " :key="index" >
            <el-col :span="24">
                <div class="user-info-cont">
                    <div >{{ getname }}</div>
                    <div>我的专家组</div>
                </div>
                <el-divider class="between"></el-divider>
<!--                <span style="margin-left: 50px;margin-bottom: 20px">小组成员：</span>-->
            </el-col>

            <el-col :span="8" v-for="(k,j) in item " :key="j">
                <el-card shadow="hover" class="mgb20" style="height:252px;"  >
                    <div class="user-info">
                        <img src="@/assets/images/img.jpg" class="user-avator" alt />
                        <div class="user-info-cont">
                            <div >{{ k.name }}</div>
                            <div>{{ k.role }}</div>
                        </div>
                    </div>
                    <div class="user-info-list">
                        系统注册时间：
                        <span>2021-7-01</span>
                    </div>
                    <div class="user-info-list">
                        审核项目数：
                        <span>2</span>
                    </div>
                </el-card>
            </el-col>

        </el-row>

    </div>
</template>

<script>
    export default {
        name: "myTeam",
        data(){
            return {
                teamname:"",
                TeamNumber:0,
                myteam:[//二维数组对象
                    [{
                        id:1,
                        team:"怀仁斋组",
                        name:"张三",
                        role:"judge",},
                    {
                        id:2,
                        team:"怀仁斋组",
                        name:"李四",
                        role:"judge"},
                    {
                        id:3,
                        team:"怀仁斋组",
                        name :"王五",
                        role: "judge"}],
                [
                    {
                    id:4,
                    team:"二维数组1",
                    name :"麻六",
                    role: "judge"},]
                ]
            }
        },
        mounted() {
          fetch("http://localhost:8888/review/queryByExpertId?expertId="+this.$store.state.E_user.userId)
            .then(respose=>respose.json())
            .then((json)=>{
                console.log(json)
                // for(let i=0;i<json.length;i++){
                //     let team=json[i].reviewId;
                //     fetch("http://localhost:8888/expert/queryByReviewId")
                // }
            })
        },
        computed:{
            getname(){
                return  this.teamname=this.myteam[0][0].team
            }
        }

    }
</script>

<style scoped>

.between{
    margin:15px  0 20px 0;
}
.user-info{
    display: flex;
    border-bottom: 2px solid #999999;
    padding-bottom: 25px;
}
.user-info img{
    border-radius: 50%;

}
.user-info-cont {
    margin-top: 20px;
    padding-left: 50px;
    flex: 1;
    font-size: 14px;
    color: #999;
}
.user-info-cont div:first-child {
    font-size: 30px;
    color: #222;
}
.user-info-cont div:last-child {
    font-size: 16px;
    margin-top: 8px;
}
.user-info-list{
    font-size: 15px;
    margin: 10px 0 20px 0;

}

</style>