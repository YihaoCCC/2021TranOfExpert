import Vue from 'vue'
import http from '../axios';


Vue.prototype.$http = http;
